// Função para obter parâmetros da URL
function getURLParameter(name) {
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get(name);
}

// Função para buscar detalhes da série pela API usando o ID
async function fetchSeriesDetails(id) {
  const API_KEY = "c7c6fe86cf0a3577128a93aa338260b5";
  const BASE_URL = "https://api.themoviedb.org/3";
  const LANGUAGE = "pt-BR";

  try {
    const response = await fetch(
      `${BASE_URL}/tv/${id}?api_key=${API_KEY}&language=${LANGUAGE}&append_to_response=credits,season`
    );
    const data = await response.json();
    return data;
  } catch (error) {
    console.error("Erro ao buscar detalhes da série:", error);
  }
}

// Função para carregar informações principais da série
async function carregarInformacoes(serieData) {
  document.getElementById("serieTitle").innerText = serieData.name;
  document.getElementById("sinopse").innerText = serieData.overview;
  document.getElementById("serieImage").src = `https://image.tmdb.org/t/p/w500${serieData.poster_path}`;
  const generos = serieData.genres.map((genre) => genre.name).join(", ");
  document.getElementById("generos").innerText = generos;
  document.getElementById("criador").innerText = serieData.created_by.map((creator) => creator.name).join(", ");
  document.getElementById("rating").innerText = serieData.vote_average;
}

// Função para carregar elenco da série
async function carregarElenco(serieData) {
  const elencoList = document.getElementById("elencoList");
  elencoList.classList.add("row", "g-2");

  const elenco = serieData.credits.cast.slice(0, 4); // Limita a 4 atores
  const fragment = document.createDocumentFragment(); // Para melhorar performance

  elenco.forEach((actor) => {
    const actorCard = document.createElement("div");
    actorCard.classList.add("col-md-3", "col-6", "d-flex", "justify-content-center");

    actorCard.innerHTML = `
      <div class="card elenco-card">
        <img src="https://image.tmdb.org/t/p/w500${actor.profile_path}" class="card-img-top" alt="${actor.name}">
        <div class="card-body text-center">
          <h4 class="card-title">${actor.name}</h4>
          <h5 class="card-subtitle text-muted">${actor.character}</h5>
        </div>
      </div>
    `;
    fragment.appendChild(actorCard);
  });

  elencoList.appendChild(fragment); // Inserir todos os cards de uma vez
}

// Função para carregar temporadas
async function carregarTemporadas(id) {
  const temporadas = await fetchSeasons(id);
  const temporadasList = document.getElementById("temporadasList");

  const fragment = document.createDocumentFragment(); // Para melhorar performance

  temporadas.forEach((temporada) => {
    const temporadaDiv = document.createElement("div");
    temporadaDiv.classList.add("temporada-item", "d-flex", "flex-column", "mb-4");

    temporadaDiv.innerHTML = `
      <img src="https://image.tmdb.org/t/p/w500${temporada.poster_path}" alt="Poster da Temporada" class="img-fluid mb-3 rounded">
      <div class="descricao">
        <h4>Temporada ${temporada.season_number}</h4>
        <p>${temporada.overview}</p>
        <p><strong>Ano:</strong> ${temporada.air_date ? temporada.air_date.split("-")[0] : "Desconhecido"} - <strong>${temporada.episode_count} Episódios</strong></p>
      </div>
    `;
    fragment.appendChild(temporadaDiv);
  });

  temporadasList.appendChild(fragment); // Inserir todas as temporadas de uma vez
}



// Função para carregar temporadas
async function carregarTemporadas(id) {
  const temporadas = await fetchSeasons(id);
  const temporadasList = document.getElementById("temporadasList");

  temporadas.forEach((temporada) => {
    const temporadaDiv = document.createElement("div");
    temporadaDiv.classList.add("temporada-item");

    temporadaDiv.innerHTML = `
      <img src="https://image.tmdb.org/t/p/w500${temporada.poster_path}" alt="Poster da Temporada">
      <div class="descricao">
        <h4>Temporada ${temporada.season_number}</h4>
        <p>${temporada.overview}</p>
        <p><strong>Ano:</strong> ${temporada.air_date ? temporada.air_date.split("-")[0] : "Desconhecido"} - <strong>${temporada.episode_count} Episódios</strong></p>
      </div>
    `;
    temporadasList.appendChild(temporadaDiv);
  });
}

// Função para buscar temporadas
async function fetchSeasons(id) {
  const API_KEY = "c7c6fe86cf0a3577128a93aa338260b5";
  const BASE_URL = "https://api.themoviedb.org/3";
  const LANGUAGE = "pt-BR";

  try {
    const response = await fetch(
      `${BASE_URL}/tv/${id}?api_key=${API_KEY}&language=${LANGUAGE}&append_to_response=seasons`
    );
    const data = await response.json();
    return data.seasons;
  } catch (error) {
    console.error("Erro ao buscar temporadas:", error);
  }
}

// Função para adicionar a série aos favoritos
async function adicionarAosFavoritos(serieData) {
  const descricaoTruncada = truncateDescription(serieData.overview);
  const novaSerie = {
    id: serieData.id,
    nome: serieData.name,
    descricao: descricaoTruncada,
    link: `detalhes_${serieData.id}.html`,
  };

  try {
    const responseGet = await fetch("http://localhost:3000/seriesFavoritas");
    const seriesFavoritas = await responseGet.json();

    if (seriesFavoritas.some((favorito) => favorito.id === serieData.id)) {
      alert("Essa série já está nos favoritos!");
      return;
    }

    const responsePost = await fetch("http://localhost:3000/seriesFavoritas", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(novaSerie),
    });

    alert("Série adicionada aos favoritos!");
  } catch (error) {
    console.error("Erro ao adicionar aos favoritos:", error);
  }
}

// Função para truncar a descrição
function truncateDescription(description) {
  return description.length > 100 ? description.substring(0, 100) + "..." : description;
}

// Função principal para carregar os detalhes da série
async function main() {
  const serieId = getURLParameter("id");
  if (!serieId) {
    alert("ID da série não encontrado!");
    return;
  }

  const serieData = await fetchSeriesDetails(serieId);
  if (!serieData) {
    alert("Detalhes da série não encontrados.");
    return;
  }

  carregarInformacoes(serieData);
  carregarElenco(serieData);
  carregarTemporadas(serieId);

  const favoritosBtn = document.getElementById("favoritosBtn");
  favoritosBtn.addEventListener("click", () => adicionarAosFavoritos(serieData));
}

// Função para adicionar a série aos favoritos
async function adicionarAosFavoritos(serieData) {
  const descricaoTruncada = truncateDescription(serieData.overview);
  const novaSerie = {
    nome: serieData.name,
    descricao: descricaoTruncada,
    link: `https://www.imdb.com/title/${serieData.id}/`,
    id: serieData.id
  };

  // Dados do usuário
  const usuario = {
    nome: "Gustavo", // O nome do usuário pode ser obtido dinamicamente se necessário
    curso: "Sistemas de Informação",
    turma: "1º semestre",
    descricao: "Estudante de Sistemas de Informação com foco em desenvolvimento back-end e grande interesse por séries e tecnologia.",
    redes_sociais: {
      linkedin: "https://www.linkedin.com/in/gustavo"
    },
    minhas_series: [novaSerie] // Adiciona a série na lista de favoritas
  };

  try {
    // Verifica se a série já foi adicionada aos favoritos
    const responseGet = await fetch("http://localhost:3000/usuarios");
    const usuarios = await responseGet.json();

    const usuarioExistente = usuarios.find((u) => u.nome === usuario.nome);
    if (usuarioExistente) {
      // Se o usuário já tiver uma lista de séries favoritas, adiciona a nova série
      const index = usuarios.indexOf(usuarioExistente);
      usuarios[index].minhas_series.push(novaSerie);
    } else {
      // Caso o usuário não exista, cria um novo usuário
      usuarios.push(usuario);
    }

    // Atualiza os dados no db.json
    const responsePost = await fetch("http://localhost:3000/usuarios", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(usuario),
    });

    alert("Série adicionada aos favoritos!");
  } catch (error) {
    console.error("Erro ao adicionar aos favoritos:", error);
  }
}

// Função para truncar a descrição
function truncateDescription(description) {
  return description.length > 100 ? description.substring(0, 100) + "..." : description;
}

// Função principal para carregar os detalhes da série
async function main() {
  const serieId = getURLParameter("id");
  if (!serieId) {
    alert("ID da série não encontrado!");
    return;
  }

  const serieData = await fetchSeriesDetails(serieId);
  if (!serieData) {
    alert("Detalhes da série não encontrados.");
    return;
  }

  carregarInformacoes(serieData);
  carregarElenco(serieData);
  carregarTemporadas(serieId);

  const favoritosBtn = document.getElementById("favoritosBtn");
  favoritosBtn.addEventListener("click", () => adicionarAosFavoritos(serieData));
}

// Chama a função principal ao carregar a página
main();