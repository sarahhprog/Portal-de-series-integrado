const API_KEY = 'b58a16a3439b866aed82f2fecf0434e1';
const BASE_URL = 'https://api.themoviedb.org/3';
const DEFAULT_LANGUAGE = 'pt-BR';

// Função para carregar séries populares
async function carregarSeriesPopulares() {
    const url = `${BASE_URL}/tv/popular?api_key=${API_KEY}&language=${DEFAULT_LANGUAGE}&page=1`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        gerarCards(data.results);
    } catch (error) {
        console.error('Erro ao carregar séries populares:', error);
    }
}

// Função para gerar os cards das séries
function gerarCards(series) {
    const explorarSeriesDiv = document.getElementById('explorarSeries');
    explorarSeriesDiv.innerHTML = ''; // Limpar a área antes de adicionar os novos cards

    series.forEach(serie => {
        if (serie.poster_path && serie.name && serie.overview) {
            const descricaoLimitada = serie.overview.length > 150
                ? serie.overview.substring(0, 150) + '...'
                : serie.overview;

            const serieCard = document.createElement('div');
            serieCard.classList.add('col-md-4', 'col-12');

            const cardHTML = `
                <div class="card">
                    <img src="https://image.tmdb.org/t/p/w500${serie.poster_path}" class="card-img-top" alt="${serie.name}">
                    <div class="card-body">
                        <h5 class="card-title text-white">${serie.name}</h5>
                        <p class="card-text">${descricaoLimitada}</p>
                        <button type="button" class="btn btn-danger">
                            <a href="detalhes.html?id=${serie.id}" class="text-light text-decoration-none">
                                Detalhes
                            </a>
                        </button>
                    </div>
                </div>
            `;

            serieCard.innerHTML = cardHTML;
            explorarSeriesDiv.appendChild(serieCard);
        }
    });
}

// Função para filtrar por categorias
function filtrarPorCategoria() {
    const categoriasID = {
        'Comédia': 35,
        'Romance': 10749,
        'Documentário': 99,
        'Terror/Drama': 18
    };

    const categoriasSelecionadas = [];
    document.querySelectorAll('.category input[type="checkbox"]:checked').forEach(checkbox => {
        const categoria = checkbox.parentElement.textContent.trim();
        categoriasSelecionadas.push(categoriasID[categoria]);
    });

    const filtro = categoriasSelecionadas.join(',');
    buscarSeriesPorCategoria(filtro);
}

// Função para buscar séries por categoria
async function buscarSeriesPorCategoria(filtro) {
    const url = `${BASE_URL}/discover/tv?api_key=${API_KEY}&language=${DEFAULT_LANGUAGE}&with_genres=${filtro}&page=1`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        gerarCards(data.results);
    } catch (error) {
        console.error('Erro ao buscar séries por categoria:', error);
    }
}

// Função de pesquisa de séries
async function pesquisarSeries() {
    const searchTerm = document.getElementById('searchInput').value.trim().toLowerCase();
    if (!searchTerm) {
        carregarSeriesPopulares();
        return;
    }

    const url = `${BASE_URL}/search/tv?api_key=${API_KEY}&language=${DEFAULT_LANGUAGE}&query=${searchTerm}&page=1`;
    try {
        const response = await fetch(url);
        const data = await response.json();
        gerarCards(data.results);
    } catch (error) {
        console.error('Erro ao pesquisar séries:', error);
    }
}

// Carregar as séries populares quando a página abrir
window.onload = carregarSeriesPopulares;
